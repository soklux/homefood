
<div class="col-xs-12">
	<div class="sidebar-nav">
		<a href="<?=Yii::app()->createUrl($url)?>" class="btn btn-primary pull-right"><?=$btn_text?></a>
	</div>
</div>
